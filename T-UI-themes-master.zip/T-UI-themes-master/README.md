# T-UI-themes
a repo full of custom themes for Linux CLI Launcher
![Google Play](https://play.google.com/store/apps/details?id=ohi.andre.consolelauncher&hl=en)
## How to Contribute a theme

- Create a new folder with its name
- include a screen.png (Screenshot of the theme)
- include a tuisettings.txt
- DONT include the settingsVersion and instruct people to paste after this property